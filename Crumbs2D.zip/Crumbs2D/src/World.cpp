#include "World.h"
#include "BodyStorage.h"
#include "ColliderStorage.h"
#include "Integrator.h"
#include "BroadPhase.h"
#include "NarrowPhase.h"
#include "ContactSolver.h"
#include "CrumbsMath.h"
#include "Profiler.h"

#include <glm/geometric.hpp>

#include <cassert>

namespace Crumbs2D
{

World::World(const SolverSettings& solverSettings)
    : m_Bodies(CreateScope<BodyStorage>()), m_Colliders(CreateScope<ColliderStorage>()),
      m_BroadPhase(CreateScope<BroadPhase>()), m_NarrowPhase(CreateScope<NarrowPhase>()),
      m_ContactSolver(CreateScope<ContactSolver>(solverSettings.Iterations, solverSettings.Beta, solverSettings.Slop)),
      m_SolverSettings(solverSettings)
{ assert(m_SolverSettings.DeltaTime > 0.0f && "DeltaTime must be positive"); }

World::~World() = default;
World::World(World&&) noexcept = default;
World& World::operator=(World&&) noexcept = default;

bool World::IsValid(const Body& body) const
{
    const Id id = {body.m_Handle, body.m_Generation};
    return body.m_World == this && m_Bodies->IsValid(id) &&
           m_Bodies->Get(id, &BodyColumns::State) != LifeState::PendingDestroy;
}

bool World::IsValid(const Collider& collider) const
{
    const Id id = {collider.m_Handle, collider.m_Generation};
    return collider.m_World == this && m_Colliders->IsValid(id) &&
           m_Colliders->Get(id, &ColliderColumns::State) != LifeState::PendingDestroy;
}

void World::MarkBodyDirty(Id body, uint8_t flags)
{
    uint8_t& dirty = m_Bodies->Get(body, &BodyColumns::DirtyFlags);
    if (dirty == 0)
        m_DirtyBodies.push_back(body);
    dirty |= flags;
}

void World::MarkColliderDirty(Id collider, uint8_t flags)
{
    uint8_t& dirty = m_Colliders->Get(collider, &ColliderColumns::DirtyFlags);
    if (dirty == 0)
        m_DirtyColliders.push_back(collider);
    dirty |= flags;
}

Collider World::AllocateCollider(Id body, const ColliderGeometry& geometry, const Transform& localTransform)
{
    ColliderStorage& colliders = *m_Colliders;

    const Id id = colliders.Add();
    colliders.Get(id, &ColliderColumns::Body) = body;
    colliders.Get(id, &ColliderColumns::Geometry) = geometry;
    colliders.Get(id, &ColliderColumns::LocalTransform) = localTransform;

    Id& first = m_Bodies->Get(body, &BodyColumns::FirstCollider);
    colliders.Get(id, &ColliderColumns::PrevCollider) = {INVALID_HANDLE, 0};
    colliders.Get(id, &ColliderColumns::NextCollider) = first;
    if (first.Handle != INVALID_HANDLE)
        colliders.Get(first, &ColliderColumns::PrevCollider) = id;
    first = id;
    m_Bodies->Get(body, &BodyColumns::ColliderCount)++;

    m_PendingColliders.push_back(id);
    MarkColliderDirty(id, ColliderDirty::Placement);
    MarkBodyDirty(body, BodyDirty::Mass);

    return Collider(id.Handle, id.Generation, this);
}

void World::RequestDestroyCollider(Id collider)
{
    ColliderStorage& colliders = *m_Colliders;
    LifeState& state = colliders.Get(collider, &ColliderColumns::State);
    if (state == LifeState::PendingDestroy)
        return;

    const Id body = colliders.Get(collider, &ColliderColumns::Body);
    const Id prev = colliders.Get(collider, &ColliderColumns::PrevCollider);
    const Id next = colliders.Get(collider, &ColliderColumns::NextCollider);
    if (prev.Handle == INVALID_HANDLE)
        m_Bodies->Get(body, &BodyColumns::FirstCollider) = next;
    else
        colliders.Get(prev, &ColliderColumns::NextCollider) = next;
    if (next.Handle != INVALID_HANDLE)
        colliders.Get(next, &ColliderColumns::PrevCollider) = prev;
    colliders.Get(collider, &ColliderColumns::PrevCollider) = {INVALID_HANDLE, 0};
    colliders.Get(collider, &ColliderColumns::NextCollider) = {INVALID_HANDLE, 0};
    m_Bodies->Get(body, &BodyColumns::ColliderCount)--;

    state = LifeState::PendingDestroy;
    m_CollidersToDestroy.push_back(collider);
    MarkBodyDirty(body, BodyDirty::Mass);
}

void World::RequestDestroyBody(Id body)
{
    LifeState& state = m_Bodies->Get(body, &BodyColumns::State);
    if (state == LifeState::PendingDestroy)
        return;

    Id current = m_Bodies->Get(body, &BodyColumns::FirstCollider);
    while (current.Handle != INVALID_HANDLE)
    {
        const Id next = m_Colliders->Get(current, &ColliderColumns::NextCollider);
        RequestDestroyCollider(current);
        current = next;
    }

    state = LifeState::PendingDestroy;
    m_BodiesToDestroy.push_back(body);
}

void World::EnsureSynchronized()
{
    if (!m_DirtyBodies.empty() || !m_DirtyColliders.empty())
        SynchronizeDirty();
}

void World::RecalculateMassData(Id body)
{
    BodyStorage& bodies = *m_Bodies;
    const ColliderStorage& colliders = *m_Colliders;

    const bool isStatic = bodies.Get(body, &BodyColumns::IsStatic) != 0;
    const float mass = bodies.Get(body, &BodyColumns::Mass);

    float totalArea = 0.0f;
    glm::vec2 weightedCenter = {0.0f, 0.0f};
    for (Id c = bodies.Get(body, &BodyColumns::FirstCollider); c.Handle != INVALID_HANDLE;
         c = colliders.Get(c, &ColliderColumns::NextCollider))
    {
        const ColliderGeometry& geometry = colliders.Get(c, &ColliderColumns::Geometry);
        const Transform& local = colliders.Get(c, &ColliderColumns::LocalTransform);
        const float area = ColliderGeometry::ComputeArea(geometry);
        totalArea += area;
        weightedCenter += area * Transform::ApplyToPoint(local, ColliderGeometry::ComputeCenter(geometry));
    }

    bodies.Get(body, &BodyColumns::InverseMass) = (!isStatic && mass > 0.0f) ? 1.0f / mass : 0.0f;

    const glm::vec2 position = bodies.Get(body, &BodyColumns::Position);
    const float rotation = bodies.Get(body, &BodyColumns::Rotation);

    if (totalArea <= 0.0f)
    {
        bodies.Get(body, &BodyColumns::MassCenterLocal) = glm::vec2(0.0f);
        bodies.Get(body, &BodyColumns::MassCenter) = position;
        bodies.Get(body, &BodyColumns::InverseInertia) = 0.0f;
        return;
    }

    const glm::vec2 massCenterLocal = weightedCenter / totalArea;
    const float density = mass / totalArea;
    float totalInertia = 0.0f;
    for (Id c = bodies.Get(body, &BodyColumns::FirstCollider); c.Handle != INVALID_HANDLE;
         c = colliders.Get(c, &ColliderColumns::NextCollider))
    {
        const ColliderGeometry& geometry = colliders.Get(c, &ColliderColumns::Geometry);
        const Transform& local = colliders.Get(c, &ColliderColumns::LocalTransform);
        const float colliderMass = density * ColliderGeometry::ComputeArea(geometry);
        const glm::vec2 offset =
            Transform::ApplyToPoint(local, ColliderGeometry::ComputeCenter(geometry)) - massCenterLocal;
        totalInertia +=
            density * ColliderGeometry::ComputeUnitInertia(geometry) + colliderMass * glm::dot(offset, offset);
    }

    bodies.Get(body, &BodyColumns::MassCenterLocal) = massCenterLocal;
    bodies.Get(body, &BodyColumns::MassCenter) = position + Rotate(massCenterLocal, rotation);
    bodies.Get(body, &BodyColumns::InverseInertia) = (!isStatic && totalInertia > 0.0f) ? 1.0f / totalInertia : 0.0f;
}

void World::SynchronizeColliders()
{
    ColliderColumns& colliders = m_Colliders->Columns;
    const BodyStorage& bodies = *m_Bodies;

    for (uint32_t i = 0; i < m_Colliders->Count(); i++)
    {
        const Id bodyId = colliders.Body.Data[i];
        const Transform bodyTransform = {
            bodies.Get(bodyId, &BodyColumns::Position), bodies.Get(bodyId, &BodyColumns::Rotation)
        };

        const Transform worldTransform = Transform::Compose(bodyTransform, colliders.LocalTransform.Data[i]);
        colliders.WorldTransform.Data[i] = worldTransform;
        colliders.AABB.Data[i] = ColliderGeometry::RecomputeAABB(colliders.Geometry.Data[i], worldTransform);
    }
}

void World::ApplyPendingChanges()
{
    for (const Id& collider : m_CollidersToDestroy)
    {
        m_BroadPhase->RemoveProxy(m_Colliders->Get(collider, &ColliderColumns::Proxy));
        m_Colliders->Remove(collider);
    }

    for (const Id& body : m_BodiesToDestroy)
    {
        m_Bodies->Remove(body);
    }

    for (const Id& body : m_PendingBodies)
    {
        if (!m_Bodies->IsValid(body))
            continue;

        m_Bodies->Get(body, &BodyColumns::State) = LifeState::Active;
    }

    for (const Id& collider : m_PendingColliders)
    {
        if (!m_Colliders->IsValid(collider))
            continue;
        m_Colliders->Get(collider, &ColliderColumns::State) = LifeState::Active;
    }

    m_CollidersToDestroy.clear();
    m_BodiesToDestroy.clear();
    m_PendingBodies.clear();
    m_PendingColliders.clear();
}

void World::SynchronizeDirty()
{
    for (const Id& body : m_DirtyBodies)
    {

        if (!m_Bodies->IsValid(body))
            continue;
        uint8_t& flags = m_Bodies->Get(body, &BodyColumns::DirtyFlags);
        if (flags & BodyDirty::Mass)
            RecalculateMassData(body);
        if (flags & BodyDirty::Transform)
        {
            m_Bodies->Get(body, &BodyColumns::MassCenter) =
                m_Bodies->Get(body, &BodyColumns::Position) +
                Rotate(m_Bodies->Get(body, &BodyColumns::MassCenterLocal), m_Bodies->Get(body, &BodyColumns::Rotation));
            ForEachColliderOf(body, [&](Id collider) { MarkColliderDirty(collider, ColliderDirty::Placement); });
        }
        flags = 0;
    }

    for (const Id& collider : m_DirtyColliders)
    {
        if (!m_Colliders->IsValid(collider))
            continue;
        uint8_t& flags = m_Colliders->Get(collider, &ColliderColumns::DirtyFlags);
        if (flags & ColliderDirty::Placement)
        {
            const Id& body = m_Colliders->Get(collider, &ColliderColumns::Body);
            Transform& transform = m_Colliders->Get(collider, &ColliderColumns::WorldTransform);
            const Transform& localTransform = m_Colliders->Get(collider, &ColliderColumns::LocalTransform);
            float bodyRotation = m_Bodies->Get(body, &BodyColumns::Rotation);

            transform.Position =
                m_Bodies->Get(body, &BodyColumns::Position) + Rotate(localTransform.Position, bodyRotation);
            transform.Rotation = localTransform.Rotation + bodyRotation;
        }
    }
}

// TODO: exercise 3 (see the refactoring plan).
bool World::ValidateInvariants() const { return true; }

void World::Step()
{
    PROFILE_SCOPE("Step");
    const float dt = m_SolverSettings.DeltaTime;

    ApplyPendingChanges();
    SynchronizeDirty();

    Integrator::IntegrateVelocities(*m_Bodies, PhysicsSettings, dt);
    m_ContactSolver->SolveContacts(*m_Bodies, *m_Colliders, m_NarrowPhase->GetContacts(), dt);
    Integrator::IntegratePositions(*m_Bodies, dt);

    SynchronizeColliders();
    m_BroadPhase->UpdateProxies(*m_Colliders);

    const std::vector<ColliderPair>& pairs = m_BroadPhase->FindPairs(*m_Bodies, *m_Colliders);
    m_NarrowPhase->FindContacts(*m_Colliders, pairs);
}

Body World::CreateBody()
{
    const Id id = m_Bodies->Add();
    m_PendingBodies.push_back(id);
    MarkBodyDirty(id, BodyDirty::Mass);
    return Body(id.Handle, id.Generation, this);
}

void World::DeleteBody(const Body& body)
{
    assert(body.m_World == this && "Body is not from this world");
    RequestDestroyBody({body.m_Handle, body.m_Generation});
}

std::vector<std::pair<Collider, Collider>> World::GetCandidatePairs()
{
    std::vector<std::pair<Collider, Collider>> result;
    for (const ColliderPair& pair : m_BroadPhase->GetPairs())
        result.emplace_back(
            Collider(pair.First().Handle, pair.First().Generation, this),
            Collider(pair.Second().Handle, pair.Second().Generation, this)
        );
    return result;
}

void World::ForEachBroadPhaseNode(const std::function<void(const AABB&, uint16_t, bool)>& f) const
{
    m_BroadPhase->GetTree().ForEachNode([&](const AABB& bound, uint16_t height, bool isLeaf) {
        f(bound, height, isLeaf);
    });
}

bool World::ValidateBroadPhase() const { return m_BroadPhase->GetTree().Validate(); }

std::vector<ContactInfo> World::GetContacts() const
{
    std::vector<ContactInfo> result;
    for (const Contact& contact : m_NarrowPhase->GetContacts())
    {
        ContactInfo info;
        info.First =
            Collider(contact.Colliders.First().Handle, contact.Colliders.First().Generation, const_cast<World*>(this));
        info.Second = Collider(
            contact.Colliders.Second().Handle, contact.Colliders.Second().Generation, const_cast<World*>(this)
        );
        info.Normal = contact.Manifold.Normal;
        info.PointCount = contact.Manifold.PointCount;
        for (uint32_t i = 0; i < contact.Manifold.PointCount; ++i)
        {
            info.Points[i] = contact.Manifold.Points[i].Position;
            info.Separations[i] = contact.Manifold.Points[i].Separation;
            info.FeatureIDs[i] = contact.Manifold.Points[i].FeatureID;
        }
        result.push_back(info);
    }
    return result;
}
template <typename F> void World::ForEachColliderOf(Id body, F&& f) const
{
    for (Id collider = m_Bodies->Get(body, &BodyColumns::FirstCollider); collider.Handle != INVALID_HANDLE;
         collider = m_Colliders->Get(collider, &ColliderColumns::NextCollider))
        f(collider);
}
} // namespace Crumbs2D